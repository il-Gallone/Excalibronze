﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeartIdentifier : MonoBehaviour {

    public int heartNumber;


}
