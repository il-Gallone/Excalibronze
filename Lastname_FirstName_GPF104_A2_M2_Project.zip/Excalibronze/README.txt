There are 3 different control schemes for the game

Scheme 1: Xbox Controller
	LeftStick: Movement
	X: Basic Attack
	Hold B: Magic Attack
	LeftStickIn + LeftStick: Change Magic Mode(Up for Fire, Right for Water, Down for Earth, Left(Unfinished))
Scheme 2: Keyboard
	Arrow Keys: Movement
	X: Basic Attack
	Hold C: Magic Attack
	Tab + Arrow Keys: Change Magic Mode(Up for Fire, Right for Water, Down for Earth, Left(Unfinished))
Scheme 3: Alt Keyboard
	W: Up
	A: Left
	D: Right
	S: Down
	K: Basic Attack
	Hold L: Magic Attack
	Backspace + WASD: Change Magic Mode(W for Fire, D for Water, S for Earth, A(Unfinished))

The door unlocking is achieved by destroying all enemies on screen.

The lose state happens when the player's health reaches 0.

Art and Documentation can be found on the HacknPlan that Trent has been connected to.